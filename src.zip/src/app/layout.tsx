import { Stack } from "expo-router";
import { SessaoProvider } from "./api/authContext";

export default function RootLayout() {
    return (
        <SessaoProvider>
            <Stack>
                <Stack.Screen name="index"/>
                <Stack.Screen name="ProfessorHome"/>
            </Stack>
        </SessaoProvider>
    )
}